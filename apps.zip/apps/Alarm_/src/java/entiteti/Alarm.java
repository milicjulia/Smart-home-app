/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entiteti;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import org.codehaus.jackson.annotate.JsonIgnore;

/**
 *
 * @author mj180394
 */
@Entity
@Table(name = "alarm")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Alarm.findAll", query = "SELECT a FROM Alarm a"),
    @NamedQuery(name = "Alarm.findByIDalarm", query = "SELECT a FROM Alarm a WHERE a.iDalarm = :iDalarm"),
    @NamedQuery(name = "Alarm.findByVreme", query = "SELECT a FROM Alarm a WHERE a.vreme = :vreme"),
    @NamedQuery(name = "Alarm.findByPonavljanje", query = "SELECT a FROM Alarm a WHERE a.ponavljanje = :ponavljanje")})
public class Alarm implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "IDalarm")
    private Integer iDalarm;
    @Basic(optional = false)
    @NotNull
    @Column(name = "vreme")
    @Temporal(TemporalType.TIMESTAMP)
    private Date vreme;
    @Column(name = "ponavljanje")
    private Integer ponavljanje;
    @JoinColumn(name = "korisnik", referencedColumnName = "IDkorisnik")
    @ManyToOne(optional = false)
    private Korisnik korisnik;
    @JoinColumn(name = "pesma", referencedColumnName = "IDpesma")
    @ManyToOne(optional = false)
    private Pesma pesma;
    @OneToMany(mappedBy = "alarm")
    private List<Obaveza> obavezaList;

    public Alarm() {
    }

    public Alarm(Integer iDalarm) {
        this.iDalarm = iDalarm;
    }

    public Alarm(Integer iDalarm, Date vreme) {
        this.iDalarm = iDalarm;
        this.vreme = vreme;
    }

    public Integer getIDalarm() {
        return iDalarm;
    }

    public void setIDalarm(Integer iDalarm) {
        this.iDalarm = iDalarm;
    }

    public Date getVreme() {
        return vreme;
    }

    public void setVreme(Date vreme) {
        this.vreme = vreme;
    }

    public Integer getPonavljanje() {
        return ponavljanje;
    }

    public void setPonavljanje(Integer ponavljanje) {
        this.ponavljanje = ponavljanje;
    }

    public Korisnik getKorisnik() {
        return korisnik;
    }

    public void setKorisnik(Korisnik korisnik) {
        this.korisnik = korisnik;
    }

    public Pesma getPesma() {
        return pesma;
    }

    public void setPesma(Pesma pesma) {
        this.pesma = pesma;
    }

    @XmlTransient
    @JsonIgnore
    public List<Obaveza> getObavezaList() {
        return obavezaList;
    }

    public void setObavezaList(List<Obaveza> obavezaList) {
        this.obavezaList = obavezaList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (iDalarm != null ? iDalarm.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Alarm)) {
            return false;
        }
        Alarm other = (Alarm) object;
        if ((this.iDalarm == null && other.iDalarm != null) || (this.iDalarm != null && !this.iDalarm.equals(other.iDalarm))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entiteti.Alarm[ iDalarm=" + iDalarm + " ]";
    }

}
