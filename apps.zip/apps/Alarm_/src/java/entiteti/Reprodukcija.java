/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entiteti;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mj180394
 */
@Entity
@Table(name = "reprodukcija")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Reprodukcija.findAll", query = "SELECT r FROM Reprodukcija r"),
    @NamedQuery(name = "Reprodukcija.findByBr", query = "SELECT r FROM Reprodukcija r WHERE r.br = :br")})
public class Reprodukcija implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "Br")
    private Integer br;
    @JoinColumn(name = "korisnik", referencedColumnName = "IDkorisnik")
    @ManyToOne(optional = false)
    private Korisnik korisnik;
    @JoinColumn(name = "pesma", referencedColumnName = "IDpesma")
    @ManyToOne(optional = false)
    private Pesma pesma;

    public Reprodukcija() {
    }

    public Reprodukcija(Integer br) {
        this.br = br;
    }

    public Integer getBr() {
        return br;
    }

    public void setBr(Integer br) {
        this.br = br;
    }

    public Korisnik getKorisnik() {
        return korisnik;
    }

    public void setKorisnik(Korisnik korisnik) {
        this.korisnik = korisnik;
    }

    public Pesma getPesma() {
        return pesma;
    }

    public void setPesma(Pesma pesma) {
        this.pesma = pesma;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (br != null ? br.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Reprodukcija)) {
            return false;
        }
        Reprodukcija other = (Reprodukcija) object;
        if ((this.br == null && other.br != null) || (this.br != null && !this.br.equals(other.br))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entiteti.Reprodukcija[ br=" + br + " ]";
    }

}
