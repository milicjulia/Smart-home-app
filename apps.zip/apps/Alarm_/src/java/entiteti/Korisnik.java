/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entiteti;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import org.codehaus.jackson.annotate.JsonIgnore;

/**
 *
 * @author mj180394
 */
@Entity
@Table(name = "korisnik")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Korisnik.findAll", query = "SELECT k FROM Korisnik k"),
    @NamedQuery(name = "Korisnik.findByIDkorisnik", query = "SELECT k FROM Korisnik k WHERE k.iDkorisnik = :iDkorisnik"),
    @NamedQuery(name = "Korisnik.findByUsername", query = "SELECT k FROM Korisnik k WHERE k.username = :username"),
    @NamedQuery(name = "Korisnik.findByPassword", query = "SELECT k FROM Korisnik k WHERE k.password = :password")})
public class Korisnik implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "IDkorisnik")
    private Integer iDkorisnik;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "username")
    private String username;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "password")
    private String password;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "korisnik")
    private List<Reprodukcija> reprodukcijaList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "korisnik")
    private List<Alarm> alarmList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "korisnik")
    private List<Obaveza> obavezaList;

    public Korisnik() {
    }

    public Korisnik(Integer iDkorisnik) {
        this.iDkorisnik = iDkorisnik;
    }

    public Korisnik(Integer iDkorisnik, String username, String password) {
        this.iDkorisnik = iDkorisnik;
        this.username = username;
        this.password = password;
    }

    public Integer getIDkorisnik() {
        return iDkorisnik;
    }

    public void setIDkorisnik(Integer iDkorisnik) {
        this.iDkorisnik = iDkorisnik;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @XmlTransient
    @JsonIgnore
    public List<Reprodukcija> getReprodukcijaList() {
        return reprodukcijaList;
    }

    public void setReprodukcijaList(List<Reprodukcija> reprodukcijaList) {
        this.reprodukcijaList = reprodukcijaList;
    }

    @XmlTransient
    @JsonIgnore
    public List<Alarm> getAlarmList() {
        return alarmList;
    }

    public void setAlarmList(List<Alarm> alarmList) {
        this.alarmList = alarmList;
    }

    @XmlTransient
    @JsonIgnore
    public List<Obaveza> getObavezaList() {
        return obavezaList;
    }

    public void setObavezaList(List<Obaveza> obavezaList) {
        this.obavezaList = obavezaList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (iDkorisnik != null ? iDkorisnik.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Korisnik)) {
            return false;
        }
        Korisnik other = (Korisnik) object;
        if ((this.iDkorisnik == null && other.iDkorisnik != null) || (this.iDkorisnik != null && !this.iDkorisnik.equals(other.iDkorisnik))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entiteti.Korisnik[ iDkorisnik=" + iDkorisnik + " ]";
    }

}
