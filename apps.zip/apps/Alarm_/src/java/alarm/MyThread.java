/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alarm;

import entiteti.Alarm;
import entiteti.Korisnik;
import entiteti.Pesma;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jms.JMSContext;
import javax.jms.JMSException;
import javax.jms.JMSProducer;
import javax.jms.TextMessage;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

/**
 *
 * @author Julija
 */
public class MyThread extends Thread{
    

    private static EntityManagerFactory emf  =Persistence.createEntityManagerFactory("Alarm_PU");
    private static EntityManager  em=null;
    private int id;


    public MyThread(int alarm) {
        if(em==null) em=emf.createEntityManager();
       id=alarm;
    }
    
    public void posaljiPesmu(Alarm a){
        try {
            JMSContext context=Main.connectionFactory.createContext();
            JMSProducer producer=context.createProducer();
            TextMessage txtmsg=context.createTextMessage();
            txtmsg.setStringProperty("radnja", "reprodukuj_pesmu");
            TypedQuery<Pesma> pk = em.createNamedQuery("Pesma.findByIDpesma", Pesma.class).setParameter("iDpesma", a.getPesma().getIDpesma());
             Pesma p = pk.getSingleResult();
             if(p==null) return;
            txtmsg.setStringProperty("pesma", p.getNaziv());
            txtmsg.setStringProperty("korisnik", a.getKorisnik().getUsername());
            producer.send(Main.reprodukcija, txtmsg);
        } catch (JMSException ex) {
            Logger.getLogger(MyThread.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
     public void run(){
        TypedQuery<Alarm> al = em.createNamedQuery("Alarm.findByIDalarm", Alarm.class).setParameter("iDalarm", id);
        List<Alarm> la = al.getResultList();
        if(la==null) return;
        Alarm a=la.get(0);
        long zvoni=2;
        
            while(true){
                
                try {
                    
                    long now=(new Date()).getTime();
                    long sleep=a.getVreme().getTime()-now;
                    if(sleep<0) break;
                    this.sleep(sleep);
                    
                    posaljiPesmu(a);
                    zvoni--;
                    if(a.getPonavljanje()==null || a.getPonavljanje()==0 || zvoni==0) break;
                    
                    long sledeciput=a.getVreme().getTime()+a.getPonavljanje()*60*1000;
                    a.setVreme(new Date(sledeciput));
                    
                } catch (InterruptedException ex) {
                    Logger.getLogger(MyThread.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
     }
    }
    
    
    

