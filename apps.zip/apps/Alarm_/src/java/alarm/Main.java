package alarm;

import entiteti.Alarm;
import entiteti.Korisnik;
import entiteti.Pesma;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.jms.ConnectionFactory;
import javax.jms.JMSConsumer;
import javax.jms.JMSContext;
import javax.jms.JMSException;
import javax.jms.JMSProducer;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.TextMessage;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.FlushModeType;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class Main {
     @Resource(lookup="jms/__defaultConnectionFactory")
    public static ConnectionFactory connectionFactory;
    @Resource(lookup="reprodukcija")
     public static Queue reprodukcija;
     @Resource(lookup="alarm")
     private static Queue alarm;
     @Resource(lookup="korisnicki_servis")
     private static Queue korisnicki_servis;
     @Resource(lookup="gui")
     private static Queue gui;
     @Resource(lookup="planer")
     private static Queue planer;
     
    
    private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("Alarm_PU");
    private static EntityManager em;
    
    static {
        em = emf.createEntityManager();
        em.setFlushMode(FlushModeType.COMMIT);
           }
    
    static ArrayList<Timer> all_timers = new ArrayList<>();
    
    public static void navij_alarm(long vreme, String korisnik){
        em.getTransaction().begin();
        TypedQuery<Korisnik> qk = em.createNamedQuery("Korisnik.findByUsername", Korisnik.class).setParameter("username", korisnik);
        Korisnik k = qk.getSingleResult();
        if(k==null) return;
        TypedQuery<Pesma> pk = em.createNamedQuery("Pesma.findByIDpesma", Pesma.class).setParameter("iDpesma", 1);
        Pesma p = pk.getSingleResult();
        if(p==null) return;
        Alarm a=new Alarm();
        a.setKorisnik(k);
        a.setPesma(p);
        a.setVreme(new Date(vreme));
        em.persist(a);
        em.getTransaction().commit();
        MyThread t=new MyThread(a.getIDalarm());
        t.start();
        
    }
    
     public static void navij_periodicni_alarm(long vreme, int perioda, String korisnik){
        em.getTransaction().begin();
        
        TypedQuery<Korisnik> qk = em.createNamedQuery("Korisnik.findByUsername", Korisnik.class).setParameter("username", korisnik);
        Korisnik k = qk.getSingleResult();
        if(k==null) return;
        
        TypedQuery<Pesma> pk = em.createNamedQuery("Pesma.findByIDpesma", Pesma.class).setParameter("iDpesma", 1);
        Pesma p = pk.getSingleResult();
        if(p==null) return;
        
        Alarm a=new Alarm();
        a.setKorisnik(k);
        a.setPesma(p);
        a.setVreme(new Date(vreme));
        a.setPonavljanje(perioda);
        
        em.persist(a);
        
        em.getTransaction().commit();
        
         MyThread t=new MyThread(a.getIDalarm());
         t.start();
        
    }
     
     
       public static void prikazi_sve_alarme(String korisnik){
        em.getTransaction().begin();
        
        TypedQuery<Alarm> q1 = em.createQuery("SELECT a FROM Alarm a WHERE a.korisnik.username=:korisnik", Alarm.class).setParameter("korisnik", korisnik);
        List<Alarm> l1 = q1.getResultList();
        if(l1.isEmpty()) System.out.println("Nema pesmi");
       
        for(Alarm i:l1){
         System.out.println("Alarm:"+i.getIDalarm()+" vreme:"+i.getVreme()+" ponavljanje:"+i.getPonavljanje()+" pesma:"+i.getPesma());
        }
        
        em.getTransaction().commit();
        
    }
       
       
       public static void konfigurisi_zvono(String pesma, String korisnik){
        em.getTransaction().begin();
      TypedQuery<Korisnik> qk = em.createNamedQuery("Korisnik.findByUsername", Korisnik.class).setParameter("username", korisnik);
        Korisnik k = qk.getSingleResult();
        if(k==null) return;
        
        TypedQuery<Pesma> pk = em.createNamedQuery("Pesma.findByNaziv", Pesma.class).setParameter("naziv", pesma);
        Pesma p = pk.getSingleResult();
        if(p==null) return;
        
         int executeUpdate = em.createQuery("UPDATE  Alarm a SET a.pesma=:p WHERE a.korisnik=:k", Alarm.class).setParameter("p", p).setParameter("k",k).executeUpdate();
           System.out.println(executeUpdate);
        em.getTransaction().commit();
        
    }
    
    public static void main(String[] args) {
        System.out.println("alarm.Main.main() pocetak");
         JMSContext context=connectionFactory.createContext();
        JMSConsumer consumer=context.createConsumer(alarm);
        Message message;
        
        while(true){
            message = consumer.receive();
        if(message instanceof TextMessage){
            try {
                TextMessage textMessage = (TextMessage) message;
                switch(textMessage.getStringProperty("radnja")){
                    case "navij_alarm":{
                        System.out.println("alarm.Main.main() alarm");
                        navij_alarm(textMessage.getLongProperty("vreme"),textMessage.getStringProperty("korisnik"));
                        break;
                    }
                    case "navij_periodicni_alarm":{
                        System.out.println("alarm.Main.main() periodicni");
                         navij_periodicni_alarm(textMessage.getLongProperty("vreme"),textMessage.getIntProperty("perioda"),textMessage.getStringProperty("korisnik"));
                        break;
                    }
                    case "prikazi_sve_alarme":{
                         prikazi_sve_alarme(textMessage.getStringProperty("korisnik"));
                        break;
                    }
                    case "konfigurisi_zvono":{
                         konfigurisi_zvono(textMessage.getStringProperty("pesma"),textMessage.getStringProperty("korisnik"));
                        break;
                    }
                }
            } catch (JMSException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }
}
            
            
        }
        
    }
    
}
