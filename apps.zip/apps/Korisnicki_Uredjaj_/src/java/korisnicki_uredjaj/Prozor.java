
package korisnicki_uredjaj;

import java.awt.Button;
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.Panel;
import java.awt.ScrollPane;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;



public class Prozor implements KeyListener, ActionListener, ItemListener{
    Frame f;
    ArrayList<Label> lista;
    static String korisnik,password;
    String pesma;
    Panel glavni, pom1, pom2, pom3;
    CheckboxGroup grupa;
    Checkbox prvi,drugi,treci,cetvrti,peti, cekiraj;
    Button klikni;
    TextField unos_kor, pesmatxt,alarmtxt, planertxt1, planertxt2, opistxt,datumtxt,lokacijatxt, lozinkatxt, textpom;
    Label unoskor, pesmalbl, alarmlbl, planerlbl1, planerlbl2, opislbl,datumlbl,lokacijalbl, unosloz, opislblpom;
    MenuBar linija;
    Menu zvuk,alarm,planer,unosk;
    MenuItem reprodukuj, sve_pesme, n_zad_t, n_zad_p, n_pon, konf_zvono, p_listati, p_dodati, p_menja, p_brise,unoskorisnika;
    ScrollPane scrollpane;
    
    
    public Prozor(){
        f= new Frame("Korisnicki uredjaj");
        f.setSize(500,300);
        f.setLayout(new FlowLayout()); 
        f.addWindowListener(new WindowAdapter() {
          @Override
	  public void windowClosing(WindowEvent windowEvent){
	   f.setVisible(false);
	     System.exit(0);
	  }        
	 }); 
        dodajMeni();
        glavni=new Panel(new FlowLayout());
        dodajUnosKorisnika();
        f.setVisible(true);
        
    }
    
    private void dodajMeni(){
        linija=new MenuBar();  
        zvuk=new Menu("Zvuk"); 
        alarm=new Menu("Alarm"); 
        planer=new Menu("Planer"); 
        unosk=new Menu("Korisnik");
        reprodukuj=new MenuItem("Reprodukuj");
        sve_pesme=new MenuItem("Prikazi sve pesme");  
        n_zad_t=new MenuItem("Navij alarm u zadatom trenutku");  
        n_zad_p=new MenuItem("Navij periodicne alarme");  
        n_pon=new MenuItem("Navij alarm da zvoni u jednom od ponudjenih trenutaka"); 
        konf_zvono=new MenuItem("Konfigurisi zeljeno zvono alarma");
        p_dodati=new MenuItem("Dodaj obavezu");
        p_brise=new MenuItem("Obrisi obavezu");
        p_listati=new MenuItem("Listaj obaveze");
        p_menja=new MenuItem("Menjaj obavezu");
        unoskorisnika=new MenuItem("Novi korisnik");
        
        unoskorisnika.addActionListener(this);
        reprodukuj.addActionListener(this);
        sve_pesme.addActionListener(this);
        n_zad_p.addActionListener(this);
        n_pon.addActionListener(this);
        n_zad_t.addActionListener(this);
        konf_zvono.addActionListener(this);
        p_brise.addActionListener(this);
        p_dodati.addActionListener(this);
        p_listati.addActionListener(this);
        p_menja.addActionListener(this);
        
        zvuk.add(reprodukuj);  
        zvuk.add(sve_pesme);  
        alarm.add(n_zad_t);
        alarm.add(n_zad_p);
        alarm.add(n_pon);
        alarm.add(konf_zvono); 
        planer.add(p_dodati);
        planer.add(p_brise);
        planer.add(p_listati);
        planer.add(p_menja);
        unosk.add(unoskorisnika);
        linija.add(zvuk);
        linija.add(alarm); 
        linija.add(planer);
        linija.add(unosk);
        f.setMenuBar(linija);  
    }

    @Override
    public void keyTyped(KeyEvent e) {
    if(e.getKeyChar()==KeyEvent.VK_ENTER){
        switch(e.getComponent().getName()){
            case "lozinkatxt":{
                korisnik=unos_kor.getText();
                password=lozinkatxt.getText();
               korisnicki_uredjaj.Main.logovanje(korisnik, password);
            System.out.println("Korisnik je "+korisnik); break;
        }
            case "pesmatxt": {
                pesma=pesmatxt.getText();
                korisnicki_uredjaj.Main.reprodukujPesmu(pesma, korisnik);
            break;}
            case "alarmtxt": {
                String[] alarmi=alarmtxt.getText().split(" ");
                String[] dat=alarmi[0].split("/");
                String[] vr=alarmi[1].split(":");
             korisnicki_uredjaj.Main.navijAlarm(Integer.parseInt(dat[0]),Integer.parseInt(dat[1]),Integer.parseInt(dat[2]),Integer.parseInt(vr[0]),Integer.parseInt(vr[1]), korisnik);
            } break;
            case "alarmperiodatxt": {
                String[] pola=alarmtxt.getText().split(" ");
                String[] dat=pola[0].split("/");
                String[] vreme=pola[1].split(":");
                String[] perioda=pola[2].split(":");
                
                korisnicki_uredjaj.Main.navijPeriodicneAlarme(Integer.parseInt(dat[0]),Integer.parseInt(dat[1]),Integer.parseInt(dat[2]),Integer.parseInt(vreme[0]),Integer.parseInt(vreme[1]),Integer.parseInt(perioda[0]),Integer.parseInt(perioda[1]),korisnik);
            } break;
            case "pesmaalarmtxt": {
                korisnicki_uredjaj.Main.konfigurisiZvono(pesmatxt.getText(),korisnik);
                break;
            
            }
           
        }
    }
    }

    @Override
    public void keyPressed(KeyEvent e) { }

    @Override
    public void keyReleased(KeyEvent e) {}

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            glavni.removeAll();
            switch(e.getActionCommand()){
                case "Novi korisnik": dodajUnosKorisnika();break;
                case "Reprodukuj": reprodukujPesmu(); break;
                case "Prikazi sve pesme": prikaziSvePesme(); break;
                case "Navij alarm u zadatom trenutku":  navijAlarm();break;
                case "Navij periodicne alarme": navijPeriodicneAlarme();break;
                case "Navij alarm da zvoni u jednom od ponudjenih trenutaka": navijPonudjenAlarm1();break;
                case "Zavrsi": navijPonudjenAlarm2(); break;
                case "Konfigurisi zeljeno zvono alarma": konfigurisiZvono(); break;
                case "Dodaj obavezu": dodajObavezu1();break;
                case "Dodaj": dodajObavezu2(); break;
                case "Obrisi obavezu": obrisiObavezu(); break;
                case "Obrisi": korisnicki_uredjaj.Main.obrisiObavezu(Integer.parseInt(opistxt.getText()), korisnik);break;
                case "Listaj obaveze": prikaziSveObaveze(); break;
                case "Menjaj obavezu": izmeniObavezu(); break;
                case "Izmeni": {
                   Main.menjajObavezu(Integer.parseInt(textpom.getText()),datumtxt.getText(), lokacijatxt.getText(), opistxt.getText(), cekiraj.getState(), korisnik);
                    break;
                }
            }   } catch (IOException ex) {
            Logger.getLogger(Prozor.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }
    
     @Override
    public void itemStateChanged(ItemEvent e) {
        if(e.getItemSelectable().toString().equalsIgnoreCase("cekirajalarm")){
           pom2.setVisible(true);
           f.setVisible(true);
        }
    }
    
    
    public void dodajUnosKorisnika(){
        unoskor=new Label("Unesite korisnika :");
        unosloz=new Label("Unesite lozinku :");
        unos_kor=new TextField();
        lozinkatxt=new TextField();
        unos_kor.setSize(20,5);
        lozinkatxt.setSize(20,5);
        unos_kor.setName("unos_kor");
        lozinkatxt.setName("lozinkatxt");
        lozinkatxt.addKeyListener(this);
        glavni.add(unoskor);
        glavni.add(unos_kor);
        glavni.add(unosloz);
        glavni.add(lozinkatxt);
        f.add(glavni);
        f.setVisible(true);
    }
    
    public void reprodukujPesmu(){
        pesmalbl=new Label("Unesite pesmu: ");
        pesmatxt=new TextField();
        pesmatxt.setSize(50, 3);
        pesmatxt.setName("pesmatxt");
        pesmatxt.addKeyListener(this);
        glavni.add(pesmalbl);
        glavni.add(pesmatxt);
        f.setVisible(true);
    }
    
    public void prikaziSvePesme(){
     Main.prikaziSvePesme(korisnik);
    }
    
    public void navijAlarm(){
        alarmlbl=new Label("Unesite vreme alarma\n Day/Month/Year Hour:Minute");
        alarmtxt=new TextField();
        alarmtxt.setSize(300, 10);
        alarmtxt.setName("alarmtxt");
        alarmtxt.addKeyListener(this);
        glavni.add(alarmlbl);
        glavni.add(alarmtxt);
        f.setVisible(true);
    }
    
   public void navijPeriodicneAlarme(){
        alarmlbl=new Label("Unesite vreme alarma sa periodom\n Day/Month/Year Hour:Minute Hour:Minute");
        alarmtxt=new TextField();
        alarmtxt.setSize(300, 10);
        alarmtxt.setName("alarmperiodatxt");
        alarmtxt.addKeyListener(this);
        glavni.add(alarmlbl);
        glavni.add(alarmtxt);
        f.setVisible(true);
    }
   
   public void navijPonudjenAlarm1(){
       grupa=new CheckboxGroup();
       prvi=new Checkbox("za 5 minuta", grupa, false);
       drugi=new Checkbox("za 15 minuta", grupa, false);
       treci=new Checkbox("za 1 sat", grupa, false);
       cetvrti=new Checkbox("za 12 sati", grupa, false);
       peti=new Checkbox("za 1 dan", grupa, false);
       
       klikni=new Button("Zavrsi");
       klikni.setName("Zavrsi");
       klikni.addActionListener(this);
       
       glavni.add(prvi);
       glavni.add(drugi);
       glavni.add(treci);
       glavni.add(cetvrti);
       glavni.add(peti);
       glavni.add(klikni);
       
       f.setVisible(true);
       
   }
   
   public void navijPonudjenAlarm2(){
       Calendar danas=Calendar.getInstance();
       long za=0;
       if(prvi.getState()) za=danas.getTimeInMillis()+5*60*1000;
       if(drugi.getState()) za=danas.getTimeInMillis()+15*60*1000;
       if(treci.getState()) za=danas.getTimeInMillis()+60*60*1000;
       if(cetvrti.getState()) za=danas.getTimeInMillis()+12*60*60*1000;
       if(peti.getState()) za=danas.getTimeInMillis()+24*60*60*1000;
       
       danas.setTimeInMillis(za);
       System.out.println("Vreme "+danas.getTime());
   Main.navijAlarm(danas.get(Calendar.DAY_OF_MONTH),danas.get(Calendar.MONTH)+1,danas.get(Calendar.YEAR), danas.get(Calendar.HOUR_OF_DAY), danas.get(Calendar.MINUTE), korisnik);
   }

    public Prozor(Frame f, ArrayList<Label> lista, String korisnik, String pesma, String password, Panel glavni, Panel pom1, Panel pom2, Panel pom3, CheckboxGroup grupa, Checkbox prvi, Checkbox drugi, Checkbox treci, Checkbox cetvrti, Checkbox peti, Checkbox cekiraj, Button klikni, TextField unos_kor, TextField pesmatxt, TextField alarmtxt, TextField planertxt1, TextField planertxt2, TextField opistxt, TextField datumtxt, TextField lokacijatxt, TextField lozinkatxt, Label unoskor, Label pesmalbl, Label alarmlbl, Label planerlbl1, Label planerlbl2, Label opislbl, Label datumlbl, Label lokacijalbl, Label unosloz, MenuBar linija, Menu zvuk, Menu alarm, Menu planer, Menu unosk, MenuItem reprodukuj, MenuItem sve_pesme, MenuItem n_zad_t, MenuItem n_zad_p, MenuItem n_pon, MenuItem konf_zvono, MenuItem p_listati, MenuItem p_dodati, MenuItem p_menja, MenuItem p_brise, MenuItem unoskorisnika, ScrollPane scrollpane) {
        this.f = f;
        this.lista = lista;
        this.korisnik = korisnik;
        this.pesma = pesma;
        this.password = password;
        this.glavni = glavni;
        this.pom1 = pom1;
        this.pom2 = pom2;
        this.pom3 = pom3;
        this.grupa = grupa;
        this.prvi = prvi;
        this.drugi = drugi;
        this.treci = treci;
        this.cetvrti = cetvrti;
        this.peti = peti;
        this.cekiraj = cekiraj;
        this.klikni = klikni;
        this.unos_kor = unos_kor;
        this.pesmatxt = pesmatxt;
        this.alarmtxt = alarmtxt;
        this.planertxt1 = planertxt1;
        this.planertxt2 = planertxt2;
        this.opistxt = opistxt;
        this.datumtxt = datumtxt;
        this.lokacijatxt = lokacijatxt;
        this.lozinkatxt = lozinkatxt;
        this.unoskor = unoskor;
        this.pesmalbl = pesmalbl;
        this.alarmlbl = alarmlbl;
        this.planerlbl1 = planerlbl1;
        this.planerlbl2 = planerlbl2;
        this.opislbl = opislbl;
        this.datumlbl = datumlbl;
        this.lokacijalbl = lokacijalbl;
        this.unosloz = unosloz;
        this.linija = linija;
        this.zvuk = zvuk;
        this.alarm = alarm;
        this.planer = planer;
        this.unosk = unosk;
        this.reprodukuj = reprodukuj;
        this.sve_pesme = sve_pesme;
        this.n_zad_t = n_zad_t;
        this.n_zad_p = n_zad_p;
        this.n_pon = n_pon;
        this.konf_zvono = konf_zvono;
        this.p_listati = p_listati;
        this.p_dodati = p_dodati;
        this.p_menja = p_menja;
        this.p_brise = p_brise;
        this.unoskorisnika = unoskorisnika;
        this.scrollpane = scrollpane;
    }
   
   
   public void konfigurisiZvono(){
      // korisnicki_uredjaj.Main.prikaziSveAlarme(korisnik);
       pesmalbl=new Label("Unesite pesmu: ");
       pesmatxt=new TextField();
       pesmatxt.setSize(50, 3);
       pesmatxt.setName("pesmaalarmtxt");
       pesmatxt.addKeyListener(this);
       glavni.add(pesmalbl);
       glavni.add(pesmatxt);
       f.setVisible(true);
   }
   
   public void dodajObavezu1(){
        pom1=new Panel(new GridLayout(4, 2));
        pom2=new Panel(new FlowLayout());
        
        datumlbl=new Label("Unesite datum, vreme i trajanje obaveze\n Day/Month/Year Hour:Minute Hour:Minute");
        lokacijalbl=new Label("Unesite lokaciju ");
        opislbl=new Label("Unesite opis ");
        datumtxt=new TextField();
        datumtxt.setSize(100, 3);
        lokacijatxt=new TextField();
        lokacijatxt.setSize(100, 3);
        opistxt=new TextField();
        opistxt.setSize(100, 3);
        
        cekiraj=new Checkbox("ima Alarm", false);
        cekiraj.setName("cekirajalarm");
      //  pesmalbl=new Label("Unesite pesmu ");
      //  pesmatxt=new TextField();
      //  pesmatxt.setSize(100, 3);
        
        klikni=new Button("Dodaj");
        klikni.setName("Dodaj");
        klikni.addActionListener(this);
        
        pom1.add(datumlbl);
        pom1.add(datumtxt);
        pom1.add(lokacijalbl);
        pom1.add(lokacijatxt);
        pom1.add(opislbl);
        pom1.add(opistxt);
        pom1.add(cekiraj);
        pom1.add(klikni);
        pom1.setVisible(true);
      //  pom2.add(pesmalbl);
      //  pom2.add(pesmatxt);
      //  pom2.setVisible(true);
        glavni.add(pom1);
      //  glavni.add(pom2);
      f.add(glavni);
       f.setVisible(true);
   
   }
   
   public void dodajObavezu2(){
       Calendar kalendar1, kalendar2;
       String[] str1,str2,str3,str4;
       String str5;
       
       if(lokacijatxt.getText()==null) str5="null";
       else str5=lokacijatxt.getText();
       
       str4=datumtxt.getText().split(" ");
       str1=str4[0].split("/");
       str2=str4[1].split(":");
       str3=str4[2].split(":");
       kalendar1=Calendar.getInstance();
       kalendar2=Calendar.getInstance();
       kalendar1.set(Integer.parseInt(str1[2]), Integer.parseInt(str1[1])-1, Integer.parseInt(str1[0]), Integer.parseInt(str2[0]), Integer.parseInt(str2[1]));
       kalendar2.set(Integer.parseInt(str1[2]), Integer.parseInt(str1[1])-1, Integer.parseInt(str1[0]), Integer.parseInt(str3[0]), Integer.parseInt(str3[1]));
     // System.out.println("GUI pise se kal1 "+kalendar1.toString()+" kal2 "+kalendar2.toString());
      if(cekiraj.getState()==true){
            System.out.println("GUItrue");
       korisnicki_uredjaj.Main.dodajObavezu(kalendar1.getTimeInMillis(), kalendar2.getTimeInMillis(), str5, opistxt.getText(),cekiraj.getState(), korisnik);
       }
       else{
            System.out.println("GUIfalse");
       korisnicki_uredjaj.Main.dodajObavezu(kalendar1.getTimeInMillis(), kalendar2.getTimeInMillis(), str5, opistxt.getText(),cekiraj.getState(), korisnik);
       }
       
   }
   
   public void obrisiObavezu() throws IOException{
       prikaziSveObaveze();
        opislbl=new Label("Unesite id obaveze koju zelite da obrisete ");
        opistxt=new TextField();
        opistxt.setSize(50, 3);
        klikni=new Button("Obrisi");
        klikni.setName("Obrisi");
        klikni.addActionListener(this);
        glavni.add(opislbl);
        glavni.add(opistxt);
        glavni.add(klikni);
        f.setVisible(true);
   
   }
   
   public void prikaziSveObaveze() throws IOException{
       korisnicki_uredjaj.Main.pokaziObaveze(korisnik);
   }
   
   public void izmeniObavezu() throws IOException{
       prikaziSveObaveze();
        pom1=new Panel(new GridLayout(7, 2));
        opislblpom=new Label("Unesite id obaveze koju zelite da izmenite ");
        textpom=new TextField("x");
        textpom.setSize(50, 3);
        datumlbl=new Label("Unesite datum, vreme i trajanje obaveze D/M/Y H:M H:M");
        datumtxt=new TextField("x/x/x x:x x:x");
        datumtxt.setSize(50, 3);
        lokacijalbl=new Label("Unesite lokaciju ");
        lokacijatxt=new TextField("x");
        lokacijatxt.setSize(50, 3);
        opislbl=new Label("Unesite opis ");
        opistxt=new TextField("x");
        opistxt.setSize(50, 3);
        cekiraj=new Checkbox("ima Alarm", false);
        cekiraj.setName("cekirajalarm");
      //  pesmalbl=new Label("Unesite pesmu ");
       // pesmatxt=new TextField("x");
       // pesmatxt.setSize(50, 3);
       klikni=new Button("Izmeni");
        klikni.setName("Izmeni");
        klikni.addActionListener(this);
        
         pom1.add(opislblpom);
         pom1.add(textpom);
        pom1.add(datumlbl);
        pom1.add(datumtxt);
        pom1.add(lokacijalbl);
        pom1.add(lokacijatxt);
        pom1.add(opislbl);
        pom1.add(opistxt);
        pom1.add(cekiraj);
        pom1.add(klikni);
        pom1.setVisible(true);
      //  pom1.add(pesmalbl);
       // pom1.add(pesmatxt);
       
        glavni.add(pom1);
   
        f.setVisible(true);
   
   }
   
   
    public static void main(String[] args) {
     new Prozor();
    
    }

   

    
}
