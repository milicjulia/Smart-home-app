package korisnicki_uredjaj;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.Base64;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import javax.swing.JList;


public class Main {
    
    static public void logovanje(String username, String password) {
        
        try {
            String userCredentials = username+":"+password;
            String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userCredentials.getBytes()));
                   
            
            URL url = new URL("http://localhost:8080/web/resources/korisnik/logovanje/" + username + "/" + password);
            HttpURLConnection konekcija = (HttpURLConnection) url.openConnection();
            konekcija.setRequestProperty("Authorization", basicAuth);
            konekcija.setRequestMethod("GET");
            
            if(konekcija.getResponseCode()!=200) {
                System.out.println("Greska pri logovanju "+konekcija.getResponseCode());
                return;
            }
            
            
            konekcija.disconnect();
        } catch (MalformedURLException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
      
        }
        
        
    

   static public void reprodukujPesmu(String p, String korisnik) {
        
        try {
            String userCredentials = Prozor.korisnik+":"+Prozor.password;
            String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userCredentials.getBytes()));
                   
            String urlpom="http://localhost:8080/web/resources/zvuk/reprodukuj/" + p + "/" + korisnik;
          
            urlpom=urlpom.replaceAll(" ", "%20");
            URL url = new URL(urlpom);
            
            HttpURLConnection konekcija = (HttpURLConnection) url.openConnection();
            konekcija.setRequestProperty("Authorization", basicAuth);
            konekcija.setRequestMethod("POST");
            
            if(konekcija.getResponseCode() != 200) {
                System.out.println("Nije pronadjena pesma");
                return;
            }
            
            konekcija.disconnect();
        } catch (MalformedURLException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
            
        }
      
    public static void prikaziSvePesme(String korisnik){
       try {
           String userCredentials = Prozor.korisnik+":"+Prozor.password;
            String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userCredentials.getBytes()));
            
           String  trenutna ,svepesme="";
           DefaultListModel<String> pesmeModel = new DefaultListModel<>();
           pesmeModel.clear();
           JList<String> pesme = new JList<String>(pesmeModel);
           URL url = new URL("http://localhost:8080/web/resources/zvuk/svepesme/" + korisnik);
           HttpURLConnection konekcija = (HttpURLConnection) url.openConnection();
           konekcija.setRequestProperty("Authorization", basicAuth);
           konekcija.setRequestMethod("GET");
           
           if (konekcija.getResponseCode() != 200) {
               System.out.println("Nisu pronadjene pesme");
               return;
           }
           
           BufferedReader bafer = new BufferedReader(new InputStreamReader((konekcija.getInputStream())));
           
           while((trenutna=bafer.readLine()) != null) {
               svepesme += trenutna;
           }
          
           konekcija.disconnect();
           } 
       catch (MalformedURLException ex) { Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex); } 
       catch (ProtocolException ex) { Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex); }
       catch (IOException ex) { Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex); }
         
    }

    public static void navijAlarm(int d, int me,int g,int s,int mi, String korisnik){
       try {
           Calendar kal=Calendar.getInstance();
           kal.set(g, me-1, d, s, mi,0);
            String urlpom="http://localhost:8080/web/resources/alarm/navij_alarm/"+kal.getTimeInMillis()+"/"+korisnik;
            System.out.println("navijam "+kal.getTimeInMillis()+" za korisnika "+korisnik+" "+urlpom);
            URL url = new URL(urlpom);
            HttpURLConnection konekcija = (HttpURLConnection) url.openConnection();
           konekcija.setRequestMethod("POST");
           
           if (konekcija.getResponseCode()!=200)  System.out.println("Greska u navijanju alarma");
           
           konekcija.disconnect();
       } 
       catch (MalformedURLException ex) { Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);} 
       catch (ProtocolException ex) { Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);} 
       catch (IOException ex) { Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);}
    }
    
    public static void navijPeriodicneAlarme(int d, int me,int g,int s, int mi, int ss, int mm, String korisnik){
         try {
           Calendar kal=Calendar.getInstance();
           kal.clear();
           kal.set(g, me-1, d, s, mi,0);
           int pon=ss*60+mm;
           String urlpom="http://localhost:8080/web/resources/alarm/navij_periodicni_alarm/"+kal.getTimeInMillis()+"/"+pon+"/"+korisnik;
             System.out.println(urlpom);
           URL url = new URL(urlpom);
           HttpURLConnection konekcija = (HttpURLConnection) url.openConnection();
           konekcija.setRequestMethod("POST");
           
           if (konekcija.getResponseCode()!=200)  System.out.println("Greska u navijanju alarma");
           
           konekcija.disconnect();
           
       } 
       catch (MalformedURLException ex) { Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);} 
       catch (ProtocolException ex) { Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);} 
       catch (IOException ex) { Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);}
    }
    
    public static void prikaziSveAlarme(String korisnik){
       try {
           String userCredentials = Prozor.korisnik+":"+Prozor.password;
            String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userCredentials.getBytes()));
            
           String  trenutna ,svialarmi="";
           DefaultListModel<String> alarmiModel = new DefaultListModel<>();
           alarmiModel.clear();
           JList<String> alarmi = new JList<String>(alarmiModel);
           URL url = new URL("http://localhost:8080/web/recources/alarm/prikazi_sve_alarme/" + korisnik);
           HttpURLConnection konekcija = (HttpURLConnection) url.openConnection();
            konekcija.setRequestProperty("Authorization", basicAuth);
           konekcija.setRequestMethod("GET");
           
           if (konekcija.getResponseCode() == 400) System.out.println("Nisu pronadjeni alarmi");
           
           BufferedReader bafer = new BufferedReader(new InputStreamReader((konekcija.getInputStream())));
           
           while((trenutna=bafer.readLine()) != null) {
               svialarmi = trenutna;
           }
         
           konekcija.disconnect();
           } 
       catch (MalformedURLException ex) { Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex); } 
       catch (ProtocolException ex) { Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex); }
       catch (IOException ex) { Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex); }
         
    }
    
    public static void konfigurisiZvono(String pesma, String korisnik){
        try{
            String userCredentials = Prozor.korisnik+":"+Prozor.password;
            String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userCredentials.getBytes()));
            
             String urlpom="http://localhost:8080/web/resources/alarm/konfigurisi_zvono/"+pesma+"/"+korisnik;
          
            urlpom=urlpom.replaceAll(" ", "%20");
      
        URL url = new URL(urlpom);
        HttpURLConnection konekcija = (HttpURLConnection) url.openConnection();
        konekcija.setRequestMethod("PUT");
         konekcija.setRequestProperty("Authorization", basicAuth);

        if (konekcija.getResponseCode()!=200) {
            System.out.println("Neuspesno konfigurisan zvuk alarma");
            return;
        }
        
        konekcija.disconnect();
        }
        catch (MalformedURLException ex) { Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex); } 
        catch (ProtocolException ex) { Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex); }
        catch (IOException ex) { Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex); }

    }
    
    public static void pokaziObaveze(String korisnik) throws IOException{
       try {
           String userCredentials = Prozor.korisnik+":"+Prozor.password;
            String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userCredentials.getBytes()));
            
           
           String linija, sviplanovi="";
           DefaultListModel<String> planoviModel = new DefaultListModel<>();
           planoviModel.clear();
           JList<String> planovi = new JList<String>(planoviModel);
           
           String urlpom="http://localhost:8080/web/resources/planer/pokazi_obaveze/" + korisnik;
           URL url = new URL(urlpom);
           HttpURLConnection konekcija = (HttpURLConnection) url.openConnection();
           konekcija.setRequestProperty("Authorization", basicAuth);
           konekcija.setRequestMethod("GET");
           
           if (konekcija.getResponseCode()!=200) { 
               System.out.println("Neuspesno prikazivanje obaveza");
               return;
           }
           
           
           
           BufferedReader bafer = new BufferedReader(new InputStreamReader((konekcija.getInputStream())));
           
           while ((linija = bafer.readLine()) != null) sviplanovi += linija;
          
           konekcija.disconnect();
       } 
        catch (MalformedURLException ex) { Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex); } 
        catch (ProtocolException ex) { Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex); }
        catch (IOException ex) { Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex); }
    }   
            
    public static void dodajObavezu(long kalendar, long trajanje, String from, String opis, boolean alarm, String korisnik){
        try{
             String linija, sviplanovi="";
           DefaultListModel<String> planoviModel = new DefaultListModel<>();
           planoviModel.clear();
           JList<String> planovi = new JList<String>(planoviModel);
            String p="null";
       
        String urlpom="http://localhost:8080/web/resources/planer/dodaj_obavezu/"+kalendar+"/"+trajanje+"/"+from+"/"+opis+"/"+alarm+"/"+korisnik;
        urlpom=urlpom.replaceAll(" ", "%20");
        URL url = new URL(urlpom);
        HttpURLConnection konekcija = (HttpURLConnection) url.openConnection();
        konekcija.setRequestMethod("POST");
        
        if (konekcija.getResponseCode()!=200) {
            System.out.println("Neuspelo pravljenje obaveze");
            return;
        }

        BufferedReader bafer = new BufferedReader(new InputStreamReader((konekcija.getInputStream())));
           
           while ((linija = bafer.readLine()) != null) sviplanovi += linija;
        
        konekcija.disconnect();
        }
        catch (MalformedURLException ex) { Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex); } 
        catch (ProtocolException ex) { Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex); }
        catch (IOException ex) { Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex); }
    }
    
    public static void obrisiObavezu(int obaveza, String korisnik){
        try{
             String userCredentials = Prozor.korisnik+":"+Prozor.password;
            String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userCredentials.getBytes()));
          
            
        URL url = new URL("http://localhost:8080/web/resources/planer/obrisi_obavezu/"+obaveza+"/"+korisnik);
        HttpURLConnection konekcija = (HttpURLConnection) url.openConnection();
        konekcija.setRequestProperty("Authorization", basicAuth);
        konekcija.setRequestMethod("DELETE");
        
        
        if (konekcija.getResponseCode()!=200) {
            System.out.println("Neuspelo brisanje obaveze");
            return;
        }

        konekcija.disconnect();
        }
        catch (MalformedURLException ex) { Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex); } 
        catch (ProtocolException ex) { Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex); }
        catch (IOException ex) { Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex); }
    }
    
    public static void menjajObavezu(int obaveza, String vreme, String from, String opis, boolean alarm, String korisnik){
        try{
               String userCredentials = Prozor.korisnik+":"+Prozor.password;
            String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userCredentials.getBytes()));
          
            
            long v,t;
            String[] pom1,pom2,pom3,pom4;
            Calendar kalendar1, kalendar2;
            if(vreme.compareTo("x/x/x x:x x:x")==0) {
                v=0;
                t=0;
            }
            else{
            pom1=vreme.split(" ");
            pom2=pom1[0].split("/");
            pom3=pom1[1].split(":");
            pom4=pom1[2].split(":");
            kalendar1=Calendar.getInstance();
            kalendar1.set(Integer.parseInt(pom2[2]), Integer.parseInt(pom2[1])-1, Integer.parseInt(pom2[0]), Integer.parseInt(pom3[0]), Integer.parseInt(pom3[1]));
             v=kalendar1.getTimeInMillis();
            kalendar2=Calendar.getInstance();
            kalendar2.set(Integer.parseInt(pom2[2]), Integer.parseInt(pom2[1])-1, Integer.parseInt(pom2[0]), Integer.parseInt(pom4[0]), Integer.parseInt(pom4[1]));
            t=kalendar2.getTimeInMillis();
            }
            
            if(from.compareTo("")==0) from="Bregalnicka 17";
        String urlpom="http://localhost:8080/web/resources/planer/menjaj_obavezu/"+obaveza+"/"+v+"/"+t+"/"+from+"/"+opis+"/"+alarm+"/"+korisnik;
        urlpom=urlpom.replaceAll(" ", "%20");
           
        URL url = new URL(urlpom);
        HttpURLConnection konekcija = (HttpURLConnection) url.openConnection();
        konekcija.setRequestProperty("Authorization", basicAuth);
        konekcija.setRequestMethod("PUT");
System.out.println(konekcija.getResponseCode());
        if (konekcija.getResponseCode()!=200) {
            System.out.println("Neuspelo menjanje obaveze");
            return; 
        }
        konekcija.disconnect();
        }
        catch (MalformedURLException ex) { Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex); } 
        catch (ProtocolException ex) { Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex); }
        catch (IOException ex) { Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex); }
    }
        
 
}

