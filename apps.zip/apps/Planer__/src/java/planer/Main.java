package planer;

import entiteti.Alarm;
import entiteti.Korisnik;
import entiteti.Obaveza;
import entiteti.Pesma;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.jms.ConnectionFactory;
import javax.jms.JMSConsumer;
import javax.jms.JMSContext;
import javax.jms.JMSException;
import javax.jms.JMSProducer;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.TextMessage;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.FlushModeType;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class Main {

    @Resource(lookup = "jms/__defaultConnectionFactory")
    private static ConnectionFactory connectionFactory;
    @Resource(lookup = "reprodukcija")
    private static Queue reprodukcija;
    @Resource(lookup = "alarm")
    private static Queue alarmA;
    @Resource(lookup = "korisnicki_servis")
    private static Queue korisnicki_servis;
    @Resource(lookup = "gui")
    private static Queue gui;
    @Resource(lookup = "planer")
    private static Queue planer;

    private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("Planer__PU");
    private static EntityManager em;

    static {
        em = emf.createEntityManager();
        em.setFlushMode(FlushModeType.COMMIT);
    }

    static ArrayList<Timer> all_timers = new ArrayList<>();
    static List<Obaveza> startTimeSorted = new ArrayList<>();
    static boolean prviput = true;
    static Date zvoni;

    public static void sortObaveze(Korisnik k) {
        startTimeSorted.clear();
        TypedQuery<Obaveza> q = em.createQuery("SELECT o FROM Obaveza o WHERE o.korisnik=:k", Obaveza.class).setParameter("k", k);
        List<Obaveza> l = q.getResultList();
        if (l.isEmpty()) {
            System.out.println("Nema obaveza");
        } else {
            for (int i = 0; i < l.size(); i++) {
                for (int j = l.size() - 1; j > i; j--) {
                    if (l.get(i).getTrajanje().compareTo(l.get(j).getPocetak()) > 0) {
                        Obaveza tmp = l.get(i);
                        l.set(i, l.get(j));
                        l.set(j, tmp);
                    }
                }
            }
            startTimeSorted = l;
        }
        //et.commit();
    }

    public static void dodaj_obavezu(long vreme, long trajanje, String from, String opis, boolean alarm, String korisnik) {
        try {
            EntityTransaction et = em.getTransaction();
            if (!et.isActive()) {
                et.begin();
            }

            TypedQuery<Korisnik> qk = em.createNamedQuery("Korisnik.findByUsername", Korisnik.class).setParameter("username", korisnik);
            Korisnik k = qk.getSingleResult();
            if (k == null) {
                System.out.println("Nema korisnika");
                return;
            }

            Obaveza o = new Obaveza();
            o.setKorisnik(k);
            if (from.compareTo("null") == 0) {
                o.setLokacija("Bregalnicka 17");
            } else {
                o.setLokacija(from);
            }
            o.setOpis(opis);
            o.setPocetak(new Date(vreme));
            o.setTrajanje(new Date(trajanje));
            sortObaveze(k);

            if (alarm && stizeLi(o.getPocetak(), o.getTrajanje(), from)) {
                TypedQuery<Pesma> qp = em.createNamedQuery("Pesma.findByIDpesma", Pesma.class).setParameter("iDpesma", 1);
                Pesma pp = qp.getSingleResult();
                if (pp == null) {
                    System.out.println("Nema pesme");
                    return;
                }

                Alarm a = new Alarm();
                a.setKorisnik(k);
                a.setPesma(pp);
                a.setVreme(zvoni);
                em.persist(a);

                et.commit();
                et.begin();

                o.setAlarm(a);
                em.persist(o);

            } else {
                System.out.println("Ne stize na obavezu");
            }

            et.commit();
            sortObaveze(k);

        } catch (IOException | GeneralSecurityException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public static void pokazi_obaveze(String korisnik) {

        TypedQuery<Obaveza> q1 = em.createQuery("SELECT o FROM Obaveza o WHERE o.korisnik.username=:korisnik", Obaveza.class).setParameter("korisnik", korisnik);
        List<Obaveza> l1 = q1.getResultList();
        if (l1.isEmpty()) {
            System.out.println("Nema obaveza");
            return;
        }

        for (Obaveza i : l1) {
            System.out.println("Obaveza:" + i.getIDobaveza() + " pocetak:" + i.getPocetak() + " trajanje:" + i.getTrajanje() + " opis:" + i.getOpis() + " lokacija: " + i.getLokacija());
        }

    }

    /*
    public static void menjaj_obavezu(int id, long vreme, long trajanje, String from, String opis, boolean alarm, String korisnik) {
        try {
            EntityTransaction et = em.getTransaction();
            if (!et.isActive()) {
                et.begin();
            }

            TypedQuery<Obaveza> o = em.createNamedQuery("Obaveza.findByIDobaveza", Obaveza.class).setParameter("iDobaveza", id);
            Obaveza obaveza = o.getSingleResult();
            if (obaveza == null) {
                System.out.println("Nema obaveze");
                return;
            }

            TypedQuery<Korisnik> qk = em.createNamedQuery("Korisnik.findByUsername", Korisnik.class).setParameter("username", korisnik);
            Korisnik k = qk.getSingleResult();
            if (k == null) {
                System.out.println("Nema korisnika");
                return;
            }

            Obaveza newobaveza = new Obaveza();

            newobaveza.setKorisnik(k);

            if (from.compareTo("x") == 0) {
                newobaveza.setLokacija(obaveza.getLokacija());
            } else {
                newobaveza.setLokacija(from.compareTo("") != 0 ? from : "Bregalnicka 17");
            }

            if (opis.compareTo("x") == 0) {
                newobaveza.setOpis(obaveza.getOpis());
            } else {
                newobaveza.setOpis(opis);
            }

            newobaveza.setPocetak(new Date(vreme));
            newobaveza.setTrajanje(new Date(trajanje));

            startTimeSorted.remove(o);
            sortObaveze(k);

            if (alarm && stizeLi(newobaveza.getPocetak(), newobaveza.getTrajanje(), newobaveza.getLokacija())) {

                JMSContext context = connectionFactory.createContext();
                JMSProducer producer = context.createProducer();
                TextMessage txtmsg = context.createTextMessage();
                try {
                    txtmsg.setStringProperty("radnja", "navij_alarm");
                    txtmsg.setLongProperty("vreme", zvoni.getTime());
                    txtmsg.setStringProperty("korisnik", korisnik);
                    producer.send(alarmA, txtmsg);
                    System.out.println("planer.Main.menjaj_obavezu() salje se ");
                } catch (JMSException ex) {
                    Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
                }

                et.commit();
                et.begin();

                TypedQuery<Alarm> createQuery = em.createQuery("SELECT MAX(a.iDalarm) FROM Alarm a", Alarm.class);
                Alarm aa = createQuery.getSingleResult();
                if (aa == null) {
                    System.out.println("Nema alarma");
                    return;
                }

                newobaveza.setAlarm(aa);
                em.remove(obaveza);
                et.commit();
                et.begin();
                em.persist(newobaveza);
            } else {
                System.out.println("Ne stize na obavezu");
            }

            et.commit();
            sortObaveze(k);

        } catch (IOException | GeneralSecurityException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }

    }*/
    public static void menjaj_obavezu(int obaveza, long vreme, long trajanje, String from, String opis, boolean alarm, String korisnik) throws GeneralSecurityException, IOException {
        EntityTransaction et = em.getTransaction();
        if (!et.isActive()) {
            et.begin();
        }

        int executeUpdate;
        Alarm a = new Alarm();

        TypedQuery<Korisnik> qk = em.createNamedQuery("Korisnik.findByUsername", Korisnik.class).setParameter("username", korisnik);
        Korisnik k = qk.getSingleResult();
        if (k == null) {
            return;
        }
        a.setKorisnik(k);

        if (vreme != 0) {
            TypedQuery<Obaveza> setParameter = em.createQuery("SELECT o FROM Obaveza o WHERE o.korisnik=:k AND o.iDobaveza=:obaveza", Obaveza.class).setParameter("obaveza", obaveza).setParameter("k", k);
            sortObaveze(k);
            startTimeSorted.remove(setParameter.getSingleResult());
            if (stizeLi(new Date(vreme), new Date(trajanje), setParameter.getSingleResult().getLokacija())) {
                executeUpdate = em.createQuery("UPDATE  Obaveza o SET o.pocetak=:vreme WHERE o.korisnik=:k AND o.iDobaveza=:obaveza", Obaveza.class).setParameter("obaveza", obaveza).setParameter("vreme", new Date(vreme)).setParameter("k", k).executeUpdate();
                executeUpdate = em.createQuery("UPDATE  Obaveza o SET o.trajanje=:trajanje WHERE o.korisnik=:k AND o.iDobaveza=:obaveza", Obaveza.class).setParameter("obaveza", obaveza).setParameter("trajanje", new Date(trajanje)).setParameter("k", k).executeUpdate();
                if (alarm) {
                    a.setVreme(zvoni);
                    TypedQuery<Pesma> qp = em.createNamedQuery("Pesma.findByIDpesma", Pesma.class).setParameter("iDpesma", 1);
                    Pesma ppp = qp.getSingleResult();
                    if (ppp == null) {
                        return;
                    }
                    a.setPesma(ppp);

                    em.persist(a);
                    et.commit();
                    et.begin();
                    sortObaveze(k);
                }
                sortObaveze(k);
            }
        }

        if (opis.compareTo("x") != 0) {
            TypedQuery<Obaveza> setParameter = em.createQuery("SELECT o FROM Obaveza o WHERE o.korisnik=:k AND o.iDobaveza=:obaveza", Obaveza.class).setParameter("obaveza", obaveza).setParameter("k", k);
            executeUpdate = em.createQuery("UPDATE  Obaveza o SET o.opis=:opis WHERE o.korisnik=:k AND o.iDobaveza=:obaveza", Obaveza.class).setParameter("obaveza", obaveza).setParameter("opis", opis).setParameter("k", k).executeUpdate();
        }

        if (from.compareTo("x") != 0) {
            TypedQuery<Obaveza> setParameter = em.createQuery("SELECT o FROM Obaveza o WHERE o.korisnik=:k AND o.iDobaveza=:obaveza", Obaveza.class).setParameter("obaveza", obaveza).setParameter("k", k);
            sortObaveze(k);
            startTimeSorted.remove(setParameter.getSingleResult());
            if (stizeLi(setParameter.getSingleResult().getPocetak(), setParameter.getSingleResult().getTrajanje(), from)) {
                try {
                    executeUpdate = em.createQuery("UPDATE  Obaveza o SET o.lokacija=:lokacija WHERE o.korisnik=:k AND o.iDobaveza=:obaveza", Obaveza.class).setParameter("obaveza", obaveza).setParameter("lokacija", from).setParameter("k", k).executeUpdate();
                    a.setVreme(zvoni);
                    JMSContext context = connectionFactory.createContext();
                    JMSProducer producer = context.createProducer();
                    TextMessage txtmsg = context.createTextMessage();
                    txtmsg.setStringProperty("radnja", "navij_alarm");
                    txtmsg.setLongProperty("vreme", zvoni.getTime());
                    txtmsg.setStringProperty("korisnik", k.getUsername());
                    producer.send(alarmA, txtmsg);
                    sortObaveze(k);
                } catch (JMSException ex) {
                    Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            sortObaveze(k);
        }

        if (!alarm) {
            TypedQuery<Obaveza> setParameter = em.createQuery("SELECT o FROM Obaveza o WHERE o.korisnik=:k AND o.iDobaveza=:obaveza", Obaveza.class).setParameter("obaveza", obaveza).setParameter("k", k);
            if (setParameter.getSingleResult().getAlarm() != null) {
                TypedQuery<Alarm> all = em.createQuery("SELECT o FROM Alarm o WHERE o.iDalarm=:id", Alarm.class).setParameter("id", setParameter.getSingleResult().getAlarm().getIDalarm());
                em.remove(all.getSingleResult());
                executeUpdate = em.createQuery("UPDATE  Obaveza o SET o.alarm=:alarm WHERE o.korisnik=:k AND o.iDobaveza=:obaveza", Obaveza.class).setParameter("obaveza", obaveza).setParameter("alarm", null).setParameter("k", k).executeUpdate();
                sortObaveze(k);
            }
        } else {
            TypedQuery<Obaveza> setParameter = em.createQuery("SELECT o FROM Obaveza o WHERE o.korisnik=:k AND o.iDobaveza=:obaveza", Obaveza.class).setParameter("obaveza", obaveza).setParameter("k", k);
            if (alarm) {
                TypedQuery<Obaveza> obave = em.createQuery("SELECT o FROM Obaveza o WHERE o.korisnik=:k AND o.iDobaveza=:obaveza", Obaveza.class).setParameter("obaveza", obaveza).setParameter("k", k);
                Obaveza ob = obave.getSingleResult();
                a.setPesma(em.createNamedQuery("Pesma.findByIDpesma", Pesma.class).setParameter("iDpesma", 1).getSingleResult());
                sortObaveze(k);
                for (int i = 0; i < startTimeSorted.size(); i++) {
                    if (startTimeSorted.get(i).getIDobaveza() == ob.getIDobaveza()) {
                        if (i != 0) {
                            startTimeSorted.remove(ob);
                            String search = Search.search(startTimeSorted.get(i - 1).getLokacija(), ob.getLokacija());
                            if (stizeLi(ob.getPocetak(), ob.getTrajanje(), ob.getLokacija())) {
                                a.setVreme(zvoni);
                                em.persist(a);
                                et.commit();
                                et.begin();
                                System.out.println("alarm se napravio 1");
                                sortObaveze(k);
                            }
                            break;
                        } else {
                            startTimeSorted.remove(ob);
                            String search = Search.search("Elektrotehnicki fakultet Beograd", ob.getLokacija());
                            if (stizeLi(ob.getPocetak(), ob.getTrajanje(), ob.getLokacija())) {
                                a.setVreme(zvoni);
                                em.persist(a);
                                et.commit();
                                et.begin();
                                System.out.println("alarm se napravio 2");
                                sortObaveze(k);
                            }
                            break;
                        }
                    } else {
                        continue;
                    }
                }
                et.commit();
                et.begin();
                TypedQuery<Obaveza> obav = em.createQuery("SELECT o FROM Obaveza o WHERE o.korisnik=:k AND o.iDobaveza=:obaveza", Obaveza.class).setParameter("obaveza", obaveza).setParameter("k", k);
                Obaveza obb = obave.getSingleResult();

                TypedQuery<Alarm> alarmm = em.createQuery("SELECT a FROM Alarm a WHERE a.korisnik=:k AND a.vreme=:zvoni", Alarm.class).setParameter("zvoni", zvoni).setParameter("k", k);
                Alarm alarm2 = alarmm.getSingleResult();
                int executeUpdate1 = em.createQuery("UPDATE Obaveza o SET o.alarm=:alarm2 WHERE o.iDobaveza=:obaveza", Obaveza.class).setParameter("alarm2", alarm2).setParameter("obaveza", obb.getIDobaveza()).executeUpdate();
                sortObaveze(k);
            }
        }

        et.commit();

        sortObaveze(k);

    }

    public static void obrisi_obavezu(int obaveza, String korisnik) {
        EntityTransaction et = em.getTransaction();
        if (!et.isActive()) {
            et.begin();
        }

        TypedQuery<Korisnik> qk = em.createNamedQuery("Korisnik.findByUsername", Korisnik.class).setParameter("username", korisnik);
        Korisnik k = qk.getSingleResult();
        if (k == null) {
            return;
        }

        TypedQuery<Obaveza> ok = em.createNamedQuery("Obaveza.findByIDobaveza", Obaveza.class).setParameter("iDobaveza", obaveza);
        Obaveza o = ok.getSingleResult();
        if (o == null) {
            return;
        }

        if (o.getAlarm() != null) {
            TypedQuery<Alarm> ak = em.createNamedQuery("Alarm.findByIDalarm", Alarm.class).setParameter("iDalarm", o.getAlarm().getIDalarm());
            Alarm a = ak.getSingleResult();
            if (a == null) {
                return;
            }

            em.remove(a);
            et.commit();
            et.begin();
        }
        em.remove(o);

        et.commit();
        sortObaveze(k);

    }

    public static boolean stizeLi(Date poc, Date tr, String lok) throws IOException, GeneralSecurityException {
        Obaveza pret = null, sled = null;
        int i = 0;
        while (i < startTimeSorted.size()) {
            sled = startTimeSorted.get(i);
            if (sled.getPocetak().before(poc)) {
                System.out.println("Ide dalje continue " + i);
                pret = sled;
                i++;
            } else {
                break;
            }
        }

        if (i == startTimeSorted.size()) {
            String search1 = Search.search(sled.getLokacija(), lok);
            zvoni = new Date(poc.getTime() - Long.parseLong(search1) * 1000);
            if (search1.compareTo("Daleko") == 0) {
                return false;
            }
            if (new Date(sled.getTrajanje().getTime() + Long.parseLong(search1) * 1000).before(poc)) {
                return true;
            } else {
                return false;
            }
        } else if (i == 0) {
            String search2 = Search.search(lok, sled.getLokacija());
            zvoni = new Date(poc.getTime() - Long.parseLong(search2) * 1000);
            if (search2.compareTo("Daleko") == 0) {
                return false;
            }
            if (new Date(tr.getTime() + Long.parseLong(search2) * 1000).before(sled.getPocetak())) {
                return true;
            } else {
                return false;
            }
        } else {
            String search3 = Search.search(pret.getLokacija(), lok);
            zvoni = new Date(poc.getTime() - Long.parseLong(search3) * 1000);
            if (search3.compareTo("Daleko") == 0) {
                return false;
            }
            if (new Date(pret.getTrajanje().getTime() + Long.parseLong(search3) * 1000).before(poc)) {
                String search4 = Search.search(lok, sled.getLokacija());
                if (search4.compareTo("Daleko") == 0) {
                    return false;
                }
                if (new Date(tr.getTime() + Long.parseLong(search4) * 1000).before(sled.getPocetak())) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }

    }

    public static void main(String[] args) {

        JMSContext context = connectionFactory.createContext();
        JMSConsumer consumer = context.createConsumer(planer);
        Message message;

        while (true) {
            message = consumer.receive();
            if (message instanceof TextMessage) {
                try {
                    TextMessage textMessage = (TextMessage) message;
                    switch (textMessage.getStringProperty("radnja")) {
                        case "dodaj_obavezu": {
                            dodaj_obavezu(textMessage.getLongProperty("vreme"), textMessage.getLongProperty("trajanje"), textMessage.getStringProperty("from"), textMessage.getStringProperty("opis"), textMessage.getBooleanProperty("alarm"), textMessage.getStringProperty("korisnik"));
                            break;
                        }
                        case "pokazi_obaveze": {
                            pokazi_obaveze(textMessage.getStringProperty("korisnik"));
                            break;
                        }
                        case "obrisi_obavezu": {
                            obrisi_obavezu(textMessage.getIntProperty("obaveza"), textMessage.getStringProperty("korisnik"));
                            break;
                        }
                        case "menjaj_obavezu": {
                            System.out.println("planer.Main.main()");
                            menjaj_obavezu(textMessage.getIntProperty("obaveza"), textMessage.getLongProperty("vreme"), textMessage.getLongProperty("trajanje"), textMessage.getStringProperty("from"), textMessage.getStringProperty("opis"), textMessage.getBooleanProperty("alarm"), textMessage.getStringProperty("korisnik"));
                            break;
                        }
                    }
                } catch (JMSException ex) {
                    Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
                } catch (GeneralSecurityException ex) {
                    Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        }

    }

}
