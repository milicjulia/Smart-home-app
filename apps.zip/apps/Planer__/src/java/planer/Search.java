package planer;

import com.google.maps.*;
import com.google.maps.errors.ApiException;
import com.google.maps.model.DistanceMatrix;
import com.google.maps.model.TravelMode;
import java.io.IOException;
import java.security.GeneralSecurityException;

public class Search {

    
    private static final String API_KEY = "AIzaSyCWzFYcQ9avpZqS241ulO2m-lohahO1nbc";
    
    public static String search(String lokacijaOd, String lokacijaDo) throws GeneralSecurityException, IOException {

      try {
            GeoApiContext context;
            DistanceMatrix result;
            DistanceMatrixApiRequest request;
            context = new GeoApiContext.Builder().apiKey(API_KEY).build();
            request = DistanceMatrixApi.newRequest(context);
            if(lokacijaOd.compareTo("null")!=0)
                result= request.origins(lokacijaOd).destinations(lokacijaDo).mode(TravelMode.DRIVING).await();
            else result= request.origins("Bregalnicka 17").destinations(lokacijaDo).mode(TravelMode.DRIVING).await();
            if (result.rows[0] == null) {
                return "";
            }
            else  return ""+result.rows[0].elements[0].duration.inSeconds;
      } 
      catch (ApiException | InterruptedException | IOException ex) {}
      
     return "Daleko";
        
    }
}
    
    
    
