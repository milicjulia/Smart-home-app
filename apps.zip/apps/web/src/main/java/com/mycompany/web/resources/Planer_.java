/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.web.resources;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.jms.ConnectionFactory;
import javax.jms.JMSContext;
import javax.jms.JMSException;
import javax.jms.JMSProducer;
import javax.jms.Queue;
import javax.jms.TextMessage;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

/**
 *
 * @author Julija
 */
@Path("planer")
public class Planer_ {

    @Resource(lookup = "jms/__defaultConnectionFactory")
    private ConnectionFactory connectionFactory;
    @Resource(lookup = "reprodukcija")
    private Queue reprodukcija;
    @Resource(lookup = "alarm")
    private Queue alarm;
    @Resource(lookup = "korisnicki_servis")
    private Queue korisnicki_servis;
    @Resource(lookup = "planer")
    private Queue planer;

    @POST
    @Path("dodaj_obavezu/{vreme}/{trajanje}/{from}/{opis}/{alarm}/{korisnik}")
    public Response dodaj_obavezu(@PathParam("vreme") long vreme, @PathParam("trajanje") long trajanje, @PathParam("from") String from, @PathParam("opis") String opis, @PathParam("alarm") boolean alarm, @PathParam("korisnik") String korisnik) {
        try {
            JMSContext context = connectionFactory.createContext();
            JMSProducer producer = context.createProducer();
            TextMessage txtmsg = context.createTextMessage();
            txtmsg.setStringProperty("radnja", "dodaj_obavezu");
            txtmsg.setLongProperty("vreme", vreme);
            txtmsg.setLongProperty("trajanje", trajanje);
            txtmsg.setStringProperty("from", from);
            txtmsg.setStringProperty("opis", opis);
            txtmsg.setBooleanProperty("alarm", alarm);

            txtmsg.setStringProperty("korisnik", korisnik);
            System.out.println("salje se obaveza");
            producer.send(planer, txtmsg);

        } catch (JMSException ex) {
            Logger.getLogger(Planer_.class.getName()).log(Level.SEVERE, null, ex);
        }

        return Response.ok().build();
    }

    @GET
    @Path("pokazi_obaveze/{korisnik}")
    public Response prikazi_obaveze(@PathParam("korisnik") String korisnik) {
        try {
            JMSContext context = connectionFactory.createContext();
            JMSProducer producer = context.createProducer();
            TextMessage txtmsg = context.createTextMessage();
            txtmsg.setStringProperty("radnja", "pokazi_obaveze");
            txtmsg.setStringProperty("korisnik", korisnik);
            producer.send(planer, txtmsg);
        } catch (JMSException ex) {
            Logger.getLogger(Planer_.class.getName()).log(Level.SEVERE, null, ex);
        }

        return Response.ok().build();
    }

    @DELETE
    @Path("obrisi_obavezu/{obaveza}/{korisnik}")
    public Response obrisi_obavezu(@PathParam("obaveza") int obaveza, @PathParam("korisnik") String korisnik) {
        try {
            JMSContext context = connectionFactory.createContext();
            JMSProducer producer = context.createProducer();
            TextMessage txtmsg = context.createTextMessage();
            txtmsg.setStringProperty("radnja", "obrisi_obavezu");
            txtmsg.setIntProperty("obaveza", obaveza);
            txtmsg.setStringProperty("korisnik", korisnik);
            producer.send(planer, txtmsg);
        } catch (JMSException ex) {
            Logger.getLogger(Planer_.class.getName()).log(Level.SEVERE, null, ex);
        }

        return Response.ok().build();
    }

    @PUT
    @Path("menjaj_obavezu/{obaveza}/{v}/{t}/{from}/{opis}/{alarm}/{korisnik}")
    public Response menjaj_obavezu(@PathParam("obaveza") int obaveza, @PathParam("v") long vreme, @PathParam("t") long trajanje, @PathParam("from") String from, @PathParam("opis") String opis, @PathParam("alarm") boolean alarm, @PathParam("korisnik") String korisnik) {
        try {
            JMSContext context = connectionFactory.createContext();
            JMSProducer producer = context.createProducer();
            TextMessage txtmsg = context.createTextMessage();
            txtmsg.setStringProperty("radnja", "menjaj_obavezu");
            txtmsg.setIntProperty("obaveza", obaveza);
            txtmsg.setLongProperty("vreme", vreme);
            txtmsg.setLongProperty("trajanje", trajanje);
            txtmsg.setStringProperty("from", from);
            txtmsg.setStringProperty("opis", opis);
            txtmsg.setBooleanProperty("alarm", alarm);

            txtmsg.setStringProperty("korisnik", korisnik);
            producer.send(planer, txtmsg);

        } catch (JMSException ex) {
            Logger.getLogger(Planer_.class.getName()).log(Level.SEVERE, null, ex);
        }

        return Response.ok().build();
    }

}
