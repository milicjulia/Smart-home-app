/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.web.resources;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.jms.ConnectionFactory;
import javax.jms.JMSContext;
import javax.jms.JMSException;
import javax.jms.JMSProducer;
import javax.jms.Queue;
import javax.jms.TextMessage;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

/**
 *
 * @author Julija
 */

@Path("alarm")
public class Alarm_ {
    @Resource(lookup="jms/__defaultConnectionFactory")
    private ConnectionFactory connectionFactory;
    @Resource(lookup="reprodukcija")
     private Queue reprodukcija;
     @Resource(lookup="alarm")
     private Queue alarm;
     @Resource(lookup="korisnicki_servis")
     private Queue korisnicki_servis;
    
      
        
     @POST
      @Path("navij_alarm/{vreme}/{korisnik}")
      public Response navij_alarm(@PathParam("vreme") long vreme,@PathParam("korisnik") String korisnik){
        try {
            JMSContext context=connectionFactory.createContext();
            JMSProducer producer=context.createProducer();
            TextMessage txtmsg=context.createTextMessage();
            txtmsg.setStringProperty("radnja","navij_alarm");
            txtmsg.setLongProperty("vreme", vreme);
            txtmsg.setStringProperty("korisnik", korisnik);
            producer.send(alarm,txtmsg);
            
        } catch (JMSException ex) {
            Logger.getLogger(Alarm_.class.getName()).log(Level.SEVERE, null, ex);
        }
        
      
        return Response.ok().build();
      }
      
      @POST
      @Path("navij_periodicni_alarm/{vreme}/{perioda}/{korisnik}")
      public Response navij_periodicni_alarm(@PathParam("vreme") long vreme,@PathParam("perioda") int perioda,@PathParam("korisnik") String korisnik){
        try {
            JMSContext context=connectionFactory.createContext();
            JMSProducer producer=context.createProducer();
            TextMessage txtmsg=context.createTextMessage();
            txtmsg.setStringProperty("radnja","navij_periodicni_alarm");
            txtmsg.setLongProperty("vreme", vreme);
            txtmsg.setIntProperty("perioda", perioda);
            txtmsg.setStringProperty("korisnik", korisnik);
            producer.send(alarm,txtmsg);
            
        } catch (JMSException ex) {
            Logger.getLogger(Alarm_.class.getName()).log(Level.SEVERE, null, ex);
        }
        
      
        return Response.ok().build();
      }
      
      
       @GET
       @Path("prikazi_sve_alarme/{korisnik}")
      public Response prikazi_sve_alarme(@PathParam("korisnik") String korisnik){
        try {
            JMSContext context=connectionFactory.createContext();
            JMSProducer producer=context.createProducer();
            TextMessage txtmsg=context.createTextMessage();
            txtmsg.setStringProperty("radnja","prikazi_sve_alarme");
            txtmsg.setStringProperty("korisnik", korisnik);
            producer.send(alarm,txtmsg);
        } catch (JMSException ex) {
            Logger.getLogger(Alarm_.class.getName()).log(Level.SEVERE, null, ex);
        }
        
      
        return Response.ok().build();
      }
      
      
       @PUT
       @Path("konfigurisi_zvono/{pesma}/{korisnik}")
      public Response konfigurisi_zvono(@PathParam("pesma") String pesma,@PathParam("korisnik") String korisnik){
        try {
            JMSContext context=connectionFactory.createContext();
            JMSProducer producer=context.createProducer();
            TextMessage txtmsg=context.createTextMessage();
            txtmsg.setStringProperty("radnja","konfigurisi_zvono");
            txtmsg.setStringProperty("korisnik", korisnik);
            txtmsg.setStringProperty("pesma", pesma);
            producer.send(alarm,txtmsg);
        } catch (JMSException ex) {
            Logger.getLogger(Alarm_.class.getName()).log(Level.SEVERE, null, ex);
        }
        
      
        return Response.ok().build();
      }
    
}
