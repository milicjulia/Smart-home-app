/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.web.resources;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.jms.ConnectionFactory;
import javax.jms.JMSContext;
import javax.jms.JMSException;
import javax.jms.JMSProducer;
import javax.jms.Queue;
import javax.jms.TextMessage;
import javax.ws.rs.POST;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;


/**
 *
 * @author Julija
 */

@Path("zvuk")
public class Uredjaj_za_reprodukciju_zvuka_ {
    
    @Resource(lookup="jms/__defaultConnectionFactory")
    private  ConnectionFactory connectionFactory;
    @Resource(lookup="reprodukcija")
     private  Queue reprodukcija;
     @Resource(lookup="alarm")
     private  Queue alarm;
     @Resource(lookup="korisnicki_servis")
     private  Queue korisnicki_servis;
     @Resource(lookup="gui")
     private  Queue gui;
    
       
     @POST
      @Path("reprodukuj/{pesma}/{korisnik}")
      public Response reprodukuj_pesmu(@PathParam("pesma") String pesma,@PathParam("korisnik") String korisnik) throws IOException{
        try {
            JMSContext context=connectionFactory.createContext();
            JMSProducer producer=context.createProducer();
            TextMessage txtmsg=context.createTextMessage();
            txtmsg.setStringProperty("radnja","reprodukuj_pesmu");
            txtmsg.setStringProperty("pesma", pesma);
            txtmsg.setStringProperty("korisnik", korisnik);
            producer.send(reprodukcija,txtmsg);
            
        } catch (JMSException ex) {
            Logger.getLogger(Uredjaj_za_reprodukciju_zvuka_.class.getName()).log(Level.SEVERE, null, ex);
        }
        
      
        return Response.ok("Pustena pesma "+pesma+" za "+korisnik).build();
      }
      
      @GET
       @Path("svepesme/{korisnik}")
      public Response prikazi_sve_pesme(@PathParam("korisnik") String korisnik) throws IOException{
        try {
            JMSContext context=connectionFactory.createContext();
            JMSProducer producer=context.createProducer();
            TextMessage txtmsg=context.createTextMessage();
            txtmsg.setStringProperty("radnja","prikazi_sve_pesme");
            txtmsg.setStringProperty("korisnik", korisnik);
            producer.send(reprodukcija,txtmsg);
        } catch (JMSException ex) {
            Logger.getLogger(Uredjaj_za_reprodukciju_zvuka_.class.getName()).log(Level.SEVERE, null, ex);
        }
        
      
        return Response.ok().build();
      }
    
    
}
