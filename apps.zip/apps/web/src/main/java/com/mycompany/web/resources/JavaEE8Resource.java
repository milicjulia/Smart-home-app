package com.mycompany.web.resources;

import entiteti.Korisnik;
import javax.persistence.EntityManager;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

/**
 *
 * @author
 */
@Path("korisnik")
public class JavaEE8Resource {

    private static EntityManager em;

    @POST
    @Path("registrovanje/{username}/{password}")
    public void createUser(@PathParam("username") String userName, @PathParam("password") String password) {
        Korisnik korisnik = new Korisnik();
        korisnik.setUsername(userName);
        korisnik.setPassword(password);
        em.persist(korisnik);
    }

    @GET
    @Path("logovanje/{username}/{password}")
    public Response getUser(@PathParam("username") String username, @PathParam("password") String password) {

        return Response.status(Response.Status.OK).build();
    }
}
