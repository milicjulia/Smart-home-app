package uredjaj_za_reprodukciju_zvuka;

import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.youtube.YouTube;
import com.google.api.services.youtube.model.SearchListResponse;
import com.google.api.services.youtube.model.SearchResult;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.List;

public class Search {

    
    private static final String API_KEY = "AIzaSyAbfYPdweZUZUvCV7Q09zLysC5984QD8OE";
    private static final long NUMBER_OF_VIDEOS_RETURNED = 1;
    private static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();
    private static YouTube youtube;
    
    public static List<SearchResult> search(String term) throws GeneralSecurityException, IOException {

        final NetHttpTransport httpTransport = GoogleNetHttpTransport.newTrustedTransport();
        
        youtube = new YouTube.Builder(httpTransport, JSON_FACTORY, (HttpRequest request) -> {}).setApplicationName("mj180394").build();

        String queryTerm = term;
        
        YouTube.Search.List search = youtube.search().list("id,snippet");
        search.setKey(API_KEY);
        search.setQ(queryTerm);
        search.setType("video");
        search.setFields("items(id/videoId,snippet/title)");
        search.setMaxResults(NUMBER_OF_VIDEOS_RETURNED);
        
        SearchListResponse searchResponse = search.execute();
        List<SearchResult> searchResultList = searchResponse.getItems();

        return searchResultList;
    }
}

