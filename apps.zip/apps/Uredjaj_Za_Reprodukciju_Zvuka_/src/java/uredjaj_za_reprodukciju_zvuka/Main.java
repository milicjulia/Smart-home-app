package uredjaj_za_reprodukciju_zvuka;

import com.google.api.services.youtube.model.SearchResult;
import entiteti.Korisnik;
import entiteti.Pesma;
import entiteti.Reprodukcija;
import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.security.GeneralSecurityException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.jms.ConnectionFactory;
import javax.jms.JMSConsumer;
import javax.jms.JMSContext;
import javax.jms.JMSException;
import javax.jms.JMSProducer;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.TextMessage;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.FlushModeType;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

/**
 *
 * @author Julija
 */
public class Main {
    
    @Resource(lookup="jms/__defaultConnectionFactory")
    private static ConnectionFactory connectionFactory;
    @Resource(lookup="reprodukcija")
     private static Queue reprodukcija;
     @Resource(lookup="alarm")
     private static Queue alarm;
     @Resource(lookup="korisnicki_servis")
     private static Queue korisnicki_servis;
     @Resource(lookup="gui")
     private static Queue gui;
     
     
       
    private static final EntityManagerFactory emf = Persistence.createEntityManagerFactory("Uredjaj_Za_Reprodukciju_Zvuka_PU");
    private static final EntityManager em;

    static {
        em = emf.createEntityManager();
        em.setFlushMode(FlushModeType.COMMIT);
           }
    
    public static  void reprodukuj_pesmu(String pesma, String korisnik){
    
        try {
            List<SearchResult> rezultat = Search.search(pesma);
            SearchResult prvi = rezultat.get(0);
            final String url = "https://www.youtube.com/watch?v=" + prvi.getId().getVideoId();
            Desktop.getDesktop().browse(URI.create(url));
            
            sacuvaj_reprodukovanu_pesmu(pesma, korisnik);
        } catch (GeneralSecurityException | IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
                
       
    }
    
    public static void sacuvaj_reprodukovanu_pesmu(String pesma, String korisnik){
        em.getTransaction().begin();
        
        TypedQuery<Korisnik> qk = em.createNamedQuery("Korisnik.findByUsername", Korisnik.class).setParameter("username", korisnik);
        Korisnik k = qk.getSingleResult();
        if(k==null) return;
        
        TypedQuery<Pesma> qp = em.createQuery("SELECT p FROM Pesma p WHERE p.naziv=:pesma", Pesma.class).setParameter("pesma", pesma);
        List<Pesma> lp = qp.getResultList();
        Pesma p;
        if(!lp.isEmpty()){
        p=lp.get(0);
        }
        else{
         p=new Pesma();
         p.setNaziv(pesma);
         em.persist(p);
        }
        
        Reprodukcija r=new Reprodukcija();
        r.setKorisnik(k);
        r.setPesma(p);
        
        em.persist(r);
        
        em.getTransaction().commit();
        
    }
    
    
    
    public static void prikazi_sve_pesme(String korisnik){
        em.getTransaction().begin();
        
       TypedQuery<Korisnik> qk = em.createNamedQuery("Korisnik.findByUsername", Korisnik.class).setParameter("username", korisnik);
        Korisnik k = qk.getSingleResult();
        if(k==null) return;
        
        TypedQuery<Reprodukcija> q1 = em.createQuery("SELECT r FROM Reprodukcija r WHERE r.korisnik.username=:korisnik", Reprodukcija.class).setParameter("korisnik", korisnik);
        Query q2 = em.createNamedQuery("Pesma.findAll");
        List<Reprodukcija> l1 = q1.getResultList();
        List<Pesma> l2=q2.getResultList();
        if(l1.isEmpty() || l2.isEmpty()) System.out.println("Nema pesmi");
       
        JMSContext context=connectionFactory.createContext();
        JMSProducer producer=context.createProducer();
        TextMessage txtmsg;
        
        for(Pesma i:l2){
            for(Reprodukcija j:l1){
                if((j.getPesma().getIDpesma())==(i.getIDpesma())){
                    System.out.println(i.getNaziv());
                    break;
                }
            }
        
        }
        
        em.getTransaction().commit();
        
    }
    
    public static void main(String []args){
         JMSContext context=connectionFactory.createContext();
        JMSConsumer consumer=context.createConsumer(reprodukcija);
        Message message;
        
        while(true){
            message = consumer.receive();
        if(message instanceof TextMessage){
            try {
                TextMessage textMessage = (TextMessage) message;
                switch(textMessage.getStringProperty("radnja")){
                    case "reprodukuj_pesmu":{
                        reprodukuj_pesmu(textMessage.getStringProperty("pesma"),textMessage.getStringProperty("korisnik"));
                        break;
                    }
                    case "prikazi_sve_pesme":{
                        prikazi_sve_pesme(textMessage.getStringProperty("korisnik"));
                        break;
                    }
                }
            } catch (JMSException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }
}
            
            
        }
    }
}
